
export class User {

	public id : number;
 	public first_name : string;
 	public last_name : string;
 	public username : string;
 	public password : string;
 	public email : string;
 	public date_of_birth : any;
 	public profile_pic : string;
	public address : string;
	public is_admin: number;
	public token : string;
	public userPhoto : string;
	public countryId: number;
	public stateId: number;
 	//Do the Needful

}
