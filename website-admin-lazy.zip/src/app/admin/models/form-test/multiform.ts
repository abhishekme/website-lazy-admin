
export class Form {

	public id : number;
 	public email : string;
 	public password : string;
 	public sel_one : string;
 	public sel_multi : any;
 	public content : string;
 	public file : string;
 	public sel_radio : string;
	public sel_check : string;
	public created: number;
 	//Do the Needful
}
