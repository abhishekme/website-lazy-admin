import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-lazy',
  templateUrl: './user-lazy.component.html'
})
export class UserLazyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
