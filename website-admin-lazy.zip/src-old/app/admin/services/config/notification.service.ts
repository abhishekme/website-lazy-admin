import { Injectable } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';

import { DictionaryService } from './dictionary.service';

@Injectable()
export class NotificationService {
    public title            : string  = "";
    public message          : string  = "";
    public json             : string  = "";
    public buttons          : any[]   = [];
    public loadingMessage   : string  = this.dictionary.loading;
    public loading          : boolean = false;
    public errorData        : any[]   = [];
	public errorGridFields  : any[]   = [
        {field: "line",  title: this.dictionary.line,  width: '10', filter: '' },
        {field: "error", title: this.dictionary.error, width: '',   filter: '' },
    ];

    constructor(public dictionary: DictionaryService,
                public snackBar: MatSnackBar) {
    }
    setMessage(title: string, message: string) {
        this.title = title;
        this.message = message;
        this.buttons = [
            {title: this.dictionary.ok, primary: true, click: () => this.clearMessage()}
        ]
    }
    setJsonMessage(title: string, message: string) {
        this.title = title;
        this.json = message;
        this.buttons = [];
    }
    setCustomMessage(title: string, message: string, buttons: any[]) {
        this.title = title;
        this.message = message;
        this.buttons = buttons;
    }
    setErrorMessage(message: string, title?) {
        if (title) {
            this.title = title;
        }
        else {
            this.title = this.dictionary.error;
        }
        this.message = message;
        this.buttons = [
            {title: this.dictionary.ok, primary: true, click: () => { this.clearMessage(); }}
        ]
        this.doneLoading();
    }
    setErrorGrid(errors, lineDescription?) {
        this.title = this.dictionary.viewResults;
        let line = this.errorGridFields.find(x => x.field == "line");
        if (lineDescription) {
            line.title = lineDescription;
            line.width = '20';
        }
        else {
            line.title = this.dictionary.line;
            line.width = '10';
        }
        this.errorData = errors;
        this.buttons = [];
        this.doneLoading();
    }
    setSnackBarInfo(message, actionMessage?, duration?, action?) {
        let snackBarRef = this.snackBar.open(message, actionMessage, {duration: duration ? duration : 4000, panelClass: ['info']});
        snackBarRef.onAction().subscribe(() => {if (action) { action();}});
    }
    setSnackBarWarning(message, actionMessage?, duration?, action?) {
        let snackBarRef = this.snackBar.open(message, actionMessage, {duration: duration ? duration : 4000, panelClass: ['warning']});
        snackBarRef.onAction().subscribe(() => {if (action) { action();}});
    }
    setSnackBarError(message, actionMessage?, duration?, action?) {
        let snackBarRef = this.snackBar.open(message, actionMessage, {duration: duration ? duration : 4000, panelClass: ['error']});
        snackBarRef.onAction().subscribe(() => {if (action) { action();}});
        this.doneLoading();
    }
    setMissingInfo(message) {
        this.setSnackBarError(this.dictionary.missingInfo, message);
    }
    clearMessage() {
        this.message = '';
        this.json = '';
        this.errorData = [];
        this.doneLoading();
    }
    isLoading() {
        this.loadingMessage = this.dictionary.loading;
        setTimeout(() => this.loading = true, 1);
    }
    doneLoading() {
        setTimeout(() => this.loading = false, 1);
    }
    isSaving() {
        this.loadingMessage = this.dictionary.saving;
        setTimeout(() => this.loading = true, 1);
    }
}